package com.ob.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static Connection conn=null;
		public static Connection DbConnection() {
			String url="jdbc:oracle:thin:@localhost:1521:Xe";
			String user="adi";
			String pass="narayana";
			
			try {
				conn=DriverManager.getConnection(url,user,pass);
			} catch (SQLException e) {
				System.out.println("connection problem  "+e.getMessage());
				
			}
			
			return conn;
			
		}

	

	

}
