package com.ob.dao;


import java.util.List;



import com.ob.dtobean.Payee;

import com.ob.exception.OnlineBankingException;


public interface IOnlineBankingDao {



	
	
	//**********************************************/
	abstract void updatepayeeaccountbal(int payeeaccountid,int transactionAmount) throws OnlineBankingException ;    /* case 7  update in user table   */
	//**********************************************/
	abstract void updatepayeraccountbal(int accountId,int transactionAmount) throws OnlineBankingException;    /* case 7  update in user table   */
	//******************************************/
	abstract void fundTransfer(int transaction_id, int accountId, int payeeaccountid, int transactionAmount) throws OnlineBankingException;  /*  case 7 fund transfetr  */
	//*********************************************/
	abstract String retrivetransactionpwd(int accountId) throws OnlineBankingException;     /*     case 7    transaction password  from user table */
	//**************************************************/
	abstract List<Payee> retrivePayeeDetails(int accountId)  throws OnlineBankingException;       /*     case 7 from payee table    */
	//***********************************************/
	abstract int storepayeeDetails(int accountId, int payeeAccountId, String nickname) throws OnlineBankingException;    /*    case 7  to payee table   */
	//***********************************************/
	abstract int checkpayeeAccountId(int payeeAccountId) throws OnlineBankingException;               /*    case 7   from master table   */
	//******************************************/
	abstract void updatetransaction(int transaction_id, String transdesc, int transactionAmount, int payeeaccountid,
			String string) throws OnlineBankingException;                             /*    case 7 from transaction table  */
	
	
	
	

	

	
	
	
	
	
	

	
	
	

	

	

}
