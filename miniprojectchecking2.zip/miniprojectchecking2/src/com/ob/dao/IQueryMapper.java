package com.ob.dao;

public interface IQueryMapper {

	String CUSTOMER_INSERT_QRY ="insert into customer values(?,?,?,?,?,SYSDATE,jdbc1_seq1.NEXTVAL)" ;/**/
	//String USER_INSERT_QRY ="insert into account_master values" ;
	
	String Update_PASSWORD="update user_table set login_password=? where user_id=?";/**/
	
	String RETRIVE_PAYEE_ID="SELECT * FROM payee_table WHERE ACCOUNT_ID=?";/**/
	String PAYEE_INSERT_QRY = "insert into payee_table values(?,?,?)";/**/	
	String RETRIVE_PAYEE_ACCOUNTID = "SELECT count(*) from Payee_table WHERE payee_account_Id = ?";/**/
	String RETRIVE_TRANSACTION_PWD = "select transaction_password from user_table where account_id=?";
	String INSERT_TRANSACTION = "insert into transactions values(?,?,SYSDATE,?,?,?)";/**/
	String INSERT_FUND_TRANSFER = "insert into fund_transfer values(?,?,?,SYSDATE,?)";/**/
	String UPDATE_PAYEE_ACCOUNTBAL = "update account_master set account_balance=? where account_id=?";/**/
	String UPDATE_PAYER_ACCOUNTBAL = "update account_master set account_balance=? where account_id=?";/**/
	String RETRIVE_ACCOUNT_BAL = "select account_balance from account_master where account_Id=?";/**/
	

}
